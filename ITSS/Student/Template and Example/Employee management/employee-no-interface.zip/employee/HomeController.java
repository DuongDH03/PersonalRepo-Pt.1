package employee;

import employee.action.IActionChangeAppGUI;
import employee.dbsubsystem.IEmployeeDB;
import employee.dbsubsystem.MemoryEmployeeDB;
import employee.viewlist.ListEmployeeController;
import employee.viewlist.ListEmployeeForm;

public class HomeController {
	private IActionChangeAppGUI actionChangeGUI;
	
	public HomeController(IActionChangeAppGUI actionChangeGUI) {
		this.actionChangeGUI = actionChangeGUI;
	}
	
	public void showEmployeeList() {
		// Create View
		ListEmployeeForm listEmployeeForm = new ListEmployeeForm();
				
		// Create Model and Controller
		IEmployeeDB db = new MemoryEmployeeDB(); 
		ListEmployeeController listEmployeeController = new ListEmployeeController(listEmployeeForm, db);
		
		
		listEmployeeForm.setListEmployeeController(listEmployeeController);
		
		// Change GUI (when view list employee button is clicked)
		actionChangeGUI.changeGUI(listEmployeeForm);
	}
}
