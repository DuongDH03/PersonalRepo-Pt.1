package employee.action;

import java.awt.Container;

public interface IActionChangeAppGUI {
	public void changeGUI(Container container);
}
