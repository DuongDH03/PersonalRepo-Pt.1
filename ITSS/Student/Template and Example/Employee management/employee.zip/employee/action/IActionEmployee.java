package employee.action;

import employee.entity.Employee;

public interface IActionEmployee {
	public void onAct(Employee emp);
}
